# Sample Java Web Application

Simple Spring Boot web app with `/hello` endpoint.

### Run locally

```bash
mvn clean package
java -jar target/demo-1.0.0.jar